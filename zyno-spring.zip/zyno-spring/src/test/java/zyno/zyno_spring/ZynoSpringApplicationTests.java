package zyno.zyno_spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZynoSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
